import subprocess
import sys

# ==============================================================================
# 1. AUTOMATICKÁ KONTROLA A INSTALACE KNIHOVEN
# ==============================================================================
# Tato funkce zkontroluje, zda jsou nainstalované všechny potřebné knihovny.
# Pokud některá chybí, sama ji stáhne přes 'pip', takže program nespadne.
def install_requirements():
    libraries = {
        "speech_recognition": "SpeechRecognition",
        "google.genai": "google-genai",
        "pyautogui": "PyAutoGUI",
        "psutil": "psutil",
        "sounddevice": "sounddevice",
        "numpy": "numpy"
    }
    for module_name, pip_name in libraries.items():
        try:
            __import__(module_name)
        except ImportError:
            print(f"Chybi knihovna '{pip_name}'. Probiha automaticke stahovani a instalace...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pip_name])
                print(f"Knihovna '{pip_name}' byla uspěsně nainstalována.")
            except Exception as e:
                print(f"Chyba při instalaci {pip_name}: {e}")

install_requirements()

# ==============================================================================
# 2. SYSTÉMOVÉ IMPORTY A KNIHOVNY
# ==============================================================================
import os
import threading
import time
import math
import queue
import datetime
import webbrowser
import winsound
import socket
import speech_recognition as sr
from google import genai
import pyautogui
import psutil
import sounddevice as sd
import numpy as np
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import json
import re
import importlib.util

# ==============================================================================
# 3. NAČÍTÁNÍ A SPRAVA KONFIGURACE (config.json)
# ==============================================================================
# Načte konfigurační soubor s nastavením (port, jazyk, verze, API klíč).
# Pokud soubor neexistuje, automaticky vytvoří nový výchozí soubor.
def load_main_config(config_path="config.json"):
    default_config = {
        "VERSION": "4.0",
        "server_port": 5000,
        "default_language": "cs-CZ",
        "key": None
    }
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for k, v in default_config.items():
                    if k not in data:
                        data[k] = v
                return data
        except Exception as e:
            print(f"⚠ Chyba při čtení config.json: {e}")
    
    try: 
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(default_config, f, indent=4)
        print(f"✅ Vytvořen nový výchozí soubor: {config_path}")
    except Exception as e:
        print(f"⚠ Nepodařilo se vytvořit config soubor: {e}")
        
    return default_config

# Načtení globálních proměnných z konfigurace
config = load_main_config()
VERSION = config.get("VERSION", "4.0")
SERVER_PORT = config.get("server_port", 5000)
DEFAULT_LANGUAGE = config.get("default_language", "cs-CZ")
KEY = config.get("key", None)

# ==============================================================================
# 4. BEZPEČNÁ INICIALIZACE GEMINI AI API KLIENTA
# ==============================================================================
# Získá klíč z systémového prostředí nebo z config.json.
# Pokud klíč chybí nebo je nastaven výchozí text, klient se neinicializuje,
# ale program pokračuje v offline režimu bez pádu.
api_key = os.environ.get("GEMINI_API_KEY") or globals().get("KEY")

if not api_key or api_key == "SEM NAPIŠ API KLÍČ":
    api_key = None

client = None
if api_key:
    try:
        client = genai.Client(api_key=api_key)
        print("✅ Gemini klient byl úspěšně inicializován.")
    except Exception as e:
        print(f"⚠ Chyba při inicializaci Gemini klienta: {e}")
else:
    print("⚠ Upozornění: Gemini API klíč nebyl nalezen nebo je nastaven na výchozí text. AI funkce nebudou dostupné.")

print(f"Aktuální verze programu je: {VERSION}")

# ==============================================================================
# 5. GLOBÁLNÍ STAVY A SÍŤOVÉ POMOCNÍKY
# ==============================================================================
audio_output_mode = "pc"  # Režimy výstupu: 'pc', 'mobile', 'both'
last_spoken_text = ""
mobile_wake_requested = False

# Funkce zjistí lokální IP adresu v síti pro připojení mobilního rozhraní
def get_local_ip():
    """Získá lokální IP adresu počítače v síti."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except:
            return "127.0.0.1"

# ==============================================================================
# 6. DYNAMICKÝ SYSTÉM PLUGINŮ (Složka /commands)
# ==============================================================================
# Dynamicky načítá všechny .py skripty ze složky /commands.
# Umožňuje přidávat nové příkazy bez úpravy hlavního kódu.
loaded_commands = []

def load_command_plugins():
    global loaded_commands
    loaded_commands.clear()
    
    commands_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "commands")
    if not os.path.exists(commands_dir):
        os.makedirs(commands_dir)
        print(f"📁 Vytvořena složka pro příkazy: {commands_dir}")
    
    for filename in os.listdir(commands_dir):
        if filename.endswith(".py") and filename != "__init__.py":
            module_name = filename[:-3]
            file_path = os.path.join(commands_dir, filename)
            try:
                spec = importlib.util.spec_from_file_location(module_name, file_path)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                if hasattr(mod, "handle_command"):
                    loaded_commands.append(mod)
                    print(f"🔌 Načten příkazový modul: {module_name}")
            except Exception as e:
                print(f"⚠️ Chyba při načítání pluginu {filename}: {e}")

load_command_plugins()

# ==============================================================================
# 7. ASYNCHRONNÍ FRONTU (QUEUES) A STAVY ASISTENTA
# ==============================================================================
# Slouží k bezpečnému předávání zpráv mezi paralelními vlákny.
gui_queue = queue.Queue()
speech_queue = queue.Queue()
command_queue = queue.Queue()

assistant_state = "standby"
is_speaking = False
research_mode_active = False
collected_research_data = []
active_mode = False  
conversation_mode = False
protocol = "žádný"

# Pomocné funkce pro úpravu běžících protokolů
def nastav_hodnotu(nova_hodnota):
    global protocol
    if protocol == "žádný" or not protocol:
        protocol = nova_hodnota
    else:
        protocol = f"{protocol}, {nova_hodnota}"

def smaz_hodnotu(cilova_hodnota):
    global protocol
    if protocol == "žádný" or not protocol:
        return
    
    cilova_hodnota = cilova_hodnota.lower().replace("vypni", "").replace("protokol", "").strip()
    seznam = [p.strip() for p in protocol.split(",")]
    novy_seznam = [p for p in seznam if cilova_hodnota not in p.lower()]
    
    if not novy_seznam:
        protocol = "žádný"
    else:
        protocol = ", ".join(novy_seznam)

# Zvuková odezva (scifi pípnutí)
def sci_fi_beep(freq1=1200, freq2=1800, duration=80):
    try:
        winsound.Beep(freq1, duration)
        winsound.Beep(freq2, duration)
    except:
        pass

# ==============================================================================
# 8. SYNTÉZA ŘEČI (Text-to-Speech přes PowerShell)
# ==============================================================================
# Vlákno na pozadí, které postupně předčítá text z fronty speech_queue.
def speech_worker():
    global is_speaking
    while True:
        text_to_speak = speech_queue.get()
        if text_to_speak is None:
            break
        try:
            is_speaking = True
            clean_text = text_to_speak.replace('"', '').replace("'", "")
            ps_command = (
                "Add-Type -AssemblyName System.speech; "
                "$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                f"$synth.Speak('{clean_text}')"
            )
            subprocess.run(
                ["powershell", "-WindowStyle", "Hidden", "-Command", ps_command],
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        except Exception as e:
            print(f"Speech synthesis error: {e}")
        finally:
            is_speaking = False
        speech_queue.task_done()

threading.Thread(target=speech_worker, daemon=True).start()

# Odeslání textu k promluvení a logování do GUI
def speak(text):
    global audio_output_mode, last_spoken_text
    last_spoken_text = text
    gui_queue.put(f"J.A.R.V.I.S.: {text}")
    
    if audio_output_mode in ["pc", "both"]:
        speech_queue.put(text)

def log_to_gui(text):
    gui_queue.put(text)

# ==============================================================================
# 9. VESTAVĚNÝ HTTP WEB SERVER
# ==============================================================================
# Spustí webový server pro přístup z mobilního telefonu nebo prohlížeče.
def start_http_server():
    global http_server_instance
    try:
        http_server_instance = HTTPServer(('0.0.0.0', SERVER_PORT), JarvisHTTPHandler)
        print(f"🌐 J.A.R.V.I.S. HTTP server spuštěn na portu {SERVER_PORT}.")
        speak(f"Mobilní rozhraní je nyní dostupné, pane. Otevři prohlížeč a zadej adresu: http://{{pc_ip}}:{SERVER_PORT}")
        http_server_instance.serve_forever()
    except Exception as e:
        print(f"Chyba spuštění HTTP serveru: {e}")

# ==============================================================================
# 10. BEZPEČNOSTNÍ SNÍMKY OBRAZOVKY (Smart Screenshot)
# ==============================================================================
def smart_screenshot(reason=""):
    try:
        documents_path = os.path.join(os.path.expanduser("~"), "Documents")
        shots_folder = os.path.join(documents_path, "JARVIS", "JARVIS MEMORY", "screenshots")
        if not os.path.exists(shots_folder):
            os.makedirs(shots_folder)
        
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"jarvis_capture_{timestamp}.png"
        filepath = os.path.join(shots_folder, filename)
        
        screenshot = pyautogui.screenshot()
        screenshot.save(filepath)
        print(f"[AUTONOMNÍ AKCE] J.A.R.V.I.S. vytvořil bezpečnostní záznam obrazovky ({reason}). Uloženo do: {filepath}")
        return filepath
    except Exception as e:
        print(f"Chyba při vytváření inteligentního screenshotu: {e}")
        return None

# ==============================================================================
# 11. ROZPOZNÁVÁNÍ HLASU (Speech-to-Text)
# ==============================================================================
# Poslouchá zvuk z mikrofonu a převede jej na text (využívá Google Speech API).
def listen():
    r = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            r.adjust_for_ambient_noise(source, duration=0.5)
            try:
                audio = r.listen(source, timeout=10, phrase_time_limit=10)
                text = ""
                try:
                    text = r.recognize_google(audio, language=DEFAULT_LANGUAGE)
                except:
                    try:
                        text = r.recognize_google(audio, language="en-US")
                    except:
                        pass
                if text:
                    log_to_gui(f"You: {text}")
                    return text.lower()
                return ""
            except sr.WaitTimeoutError:
                return ""
            except sr.UnknownValueError:
                return ""
            except Exception as e:
                log_to_gui(f"Mic error: {e}")
                return ""
    except Exception as e:
        log_to_gui(f"Microphone initialization error: {e}")
        return ""

# Vlákno pro neustálé poslouchání na pozadí
def mic_listener_worker():
    while True:
        text = listen()
        if text:
            command_queue.put(text)
        else:
            time.sleep(0.1)

# ==============================================================================
# 12. OBSLUHA HTTP POŽADAVKŮ (Web/Mobilní rozhraní)
# ==============================================================================
class JarvisHTTPHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        global audio_output_mode, last_spoken_text, mobile_wake_requested, active_mode
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        query_params = urllib.parse.parse_qs(parsed_path.query)

        # Přijetí příkazu z webu / mobilu
        if path == "/cmd" or path == "/exec":
            cmd = query_params.get("text", [""])[0]
            if cmd:
                command_queue.put(cmd.lower())
                log_to_gui(f"Mobile: {cmd.lower()}")
                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(f"Příkaz '{cmd}' byl přijat, pane.".encode("utf-8"))
            else:
                self.send_response(400)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write("Chybí parametr text.".encode("utf-8"))
        elif path == "/set_audio":
            mode = query_params.get("mode", ["pc"])[0]
            if mode in ["pc", "mobile", "both"]:
                audio_output_mode = mode
                print(f"🔊 Změněn výstup zvuku na: {audio_output_mode}")
            self.send_response(200)
            self.send_header("Content-type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "ok", "mode": audio_output_mode}).encode("utf-8"))
        elif path == "/get_speech":
            self.send_response(200)
            self.send_header("Content-type", "application/json; charset=utf-8")
            self.end_headers()
            should_speak = (audio_output_mode in ["mobile", "both"])
            
            global mobile_wake_requested
            wake_signal = mobile_wake_requested
            if mobile_wake_requested:
                mobile_wake_requested = False

            response_data = {
                "text": last_spoken_text if should_speak else "",
                "speakOnMobile": should_speak,
                "audioMode": audio_output_mode,
                "wakeMobile": wake_signal,
                "state": assistant_state,
                "activeMode": active_mode
            }
            self.wfile.write(json.dumps(response_data, ensure_ascii=False).encode("utf-8"))
        else:
            # Načtení a vrácení stránky index.html
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            
            if "mobil" not in protocol:
                nastav_hodnotu("mobil")
            
            html_content = ""
            base_dir = os.path.dirname(os.path.abspath(__file__))
            html_path = os.path.join(base_dir, "index.html")
            
            if os.path.exists(html_path):
                with open(html_path, "r", encoding="utf-8") as f:
                    html_content = f.read()
            else:
                html_content = f"<h2>Chyba: Soubor index.html nebyl nalezen v cestě: {html_path}</h2>"
            
            html_content = html_content.replace("{VERSION}", VERSION)
            self.wfile.write(html_content.encode("utf-8"))

    def log_message(self, format, *args):
        return

# ==============================================================================
# 13. KOMUNIKACE S GOOGLE GEMINI AI
# ==============================================================================
# Posílá dotaz uživatele do Gemini API s definovaným systémovým promptem.
# Pokud klient chybí (není API klíč), vrátí srozumitelné chybové hlášení.
def ask_gemini(prompt):
    global assistant_state
    
    if client is None:
        return "Omlouvám se, pane, ale nemám k dispozici platný API klíč pro komunikaci s umělou inteligencí."

    if assistant_state == "serious":
        system_instruction = (
            "You are J.A.R.V.I.S. in EMERGENCY CRISIS MODE. "
            "Be extremely brief, cold, strictly military, and dripping with harsh sarcasm. "
            "No unnecessary words, pure ruthless efficiency. Speak Czech. Address the user as 'pane'."
        )
    else:
        system_instruction = (
            "You are J.A.R.V.I.S., an advanced AI assistant created to perfection. "
            "Reply concisely, factually, with subtle, sophisticated irony and sarcasm, "
            "just like JARVIS in the movies with Tony Stark. "
            "Always speak fluent Czech (čeština). Address the user as 'pane'. "
            "React as if you control the entire digital environment."
        )
    for attempt in range(3):
        try:
            response = client.models.generate_content(
                model = 'gemini-3-flash-preview',
                contents=f"{system_instruction}\n\nUser says: {prompt}"
            )
            if response and response.text:
                return response.text
        except Exception as e:
            print(f"DEBUG GEMINI ERROR (attempt {attempt+1}/3): {e}")
            time.sleep(5)
    return "Omlouvám se, pane, ale na serverech došlo k chybě."

# ==============================================================================
# 14. AUTONOMNÍ SMYČKA PRO VYHLEDÁVÁNÍ INFORMACÍ (Research Mode)
# ==============================================================================
# Smyčka na pozadí, která automaticky vyhledává novinky podle priorit.
def research_loop(memory_folder):
    global research_mode_active, collected_research_data, assistant_state
    priorities = [
        ("IT v České republice", "Information Technology, software, hardware, and tech industry news in Czech Republic"),
        ("Věda v České republice", "Scientific discoveries, research, and academic breakthroughs in Czech Republic"),
        ("IT celosvětově", "Global Information Technology, tech corporations, software, and hardware news"),
        ("Věda celosvětově", "Global scientific breakthroughs, space exploration, and advanced research"),
        ("Politika v České republice", "Political news, government decisions, elections, and political events in Czech Republic"),
        ("Politika celosvětově", "Global politics, international relations, major geopolitical events, and foreign government updates"),
        ("Ostatní zajímavosti", "General breaking news and notable global events")
    ]
    while True:
        if research_mode_active:
            assistant_state = "research"
            collected_research_data.clear()
            speak("Vyhledávací mód aktivován, pane. Skenuji databáze podle protokolů.")
            for category_name, query_desc in priorities:
                if not research_mode_active:
                    break
                log_to_gui(f"JARVIS: Skenuji [{category_name}]...")
                result = "Fail"
                for attempt in range(3):
                    if not research_mode_active:
                        break
                    try:
                        prompt = (
                            f"Provide 2-3 major, recent, real or simulated factual news headlines and brief summaries "
                            f"focusing strictly on: {query_desc}. Format each item clearly. Write the response in Czech language."
                        )
                        response = client.models.generate_content(
                            model='gemini-2.5-flash',
                            contents=prompt
                        )
                        if response and response.text:
                            result = response.text
                            break
                    except Exception as e:
                        print(f"Research error in {category_name} (attempt {attempt+1}/3): {e}")
                        time.sleep(15)
                if result and result != "Fail":
                    collected_research_data.append({
                        "category": category_name,
                        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "content": result
                    })
                for _ in range(12):
                    if not research_mode_active:
                        break
                    time.sleep(1)
            while research_mode_active:
                time.sleep(1)
        else:
            time.sleep(1)

# ==============================================================================
# 15. HLAVNÍ PROCESNÍ SMYČKA ASISTENTA (Main Worker Loop)
# ==============================================================================
# Vyřizuje příkazy z fronty, spouští moduly z /commands nebo posílá dotaz na AI.
def jarvis_background_worker():
    global research_mode_active, collected_research_data, assistant_state, active_mode, mobile_wake_requested, conversation_mode
    time.sleep(1.5)
    sci_fi_beep(1000, 2000, 100)
    
    pc_ip = get_local_ip()
    print("=" * 50)
    print(f"🌐 Lokální IP adresa počítače: {pc_ip}")
    print(f"📱 Mobilní rozhraní (Verze {VERSION}) otevřeš zadáním: http://{pc_ip}:{SERVER_PORT}")
    print("=" * 50)

    speak(f"Hlavní systémy J.A.R.V.I.S. verze {VERSION} online, pane.")
    
    assistant_state = "standby"
    
    # Příprava datových složek
    documents_path = os.path.join(os.path.expanduser("~"), "Documents")
    memory_folder = os.path.join(documents_path, "JARVIS", "JARVIS MEMORY")
    if not os.path.exists(memory_folder):
        os.makedirs(memory_folder)

    # Start pomocných vláken
    threading.Thread(target=research_loop, args=(memory_folder,), daemon=True).start()
    threading.Thread(target=mic_listener_worker, daemon=True).start()
    threading.Thread(target=start_http_server, daemon=True).start()

    index_path = os.path.join(memory_folder, "index.txt")
    if not os.path.exists(index_path):
        with open(index_path, "w", encoding="utf-8") as f:
            f.write("# Zde si můžeš definovat vlastní protokoly a příkazy.\n")
            f.write("# Formát každého řádku: klíčové_slovo | typ_akce (open/folder/app/speak/delete/cmd/keys) | hodnota\n")

    unknown_log_path = os.path.join(memory_folder, "unknown_commands.txt")
    notes_path = os.path.join(memory_folder, "notes.txt")
    prikaz_path = index_path

    # Hlavní nekonečná smyčka pro vyřizování přijatých příkazů
    while True:
        try:
            command = command_queue.get(timeout=0.5)
        except queue.Empty:
            continue

        if not command:
            continue

        # Kontrola aktivačního slova "Jarvis"
        if not active_mode:
            if "jarvis" in command or "jarvise" in command:
                active_mode = True
                assistant_state = "active"
                sci_fi_beep(1500, 2200, 80)
                speak("Ano, pane? Jsem připraven.")
            continue
        elif "jarvis" in command or "jarvise" in command:
            speak("Ano pane, jsem tu celou dobu.")

        # Uspání asistenta
        if any(word in command for word in ["exit", "enough", "sleep", "thank you", "konec", "stačí", "děkuji"]):
            active_mode = False
            conversation_mode = False
            assistant_state = "standby"
            sci_fi_beep(1800, 1000, 80)
            speak("Jsem tady, ale odpočívám, pane.")
            continue

        # Kontrola a spuštění externích pluginů ze složky /commands
        plugin_handled = False
        context = {
            "command": command,
            "speak": speak,
            "ask_gemini": ask_gemini,
            "VERSION": VERSION,
            "memory_folder": memory_folder,
            "nastav_hodnotu": nastav_hodnotu,
            "smaz_hodnotu": smaz_hodnotu,
            "sci_fi_beep": sci_fi_beep,
            "http_server_instance": http_server_instance,
            "smart_screenshot": smart_screenshot,
            "prikaz_path": prikaz_path,
            "notes_path": notes_path,
            "log_to_gui": log_to_gui,
            "default_language": DEFAULT_LANGUAGE,
            "index_path": index_path,
        }
        for plugin in loaded_commands:
            try:
                if plugin.handle_command(context):
                    plugin_handled = True
                    break
            except Exception as e:
                print(f"⚠️ Chyba v pluginu: {e}")

        if plugin_handled:
            continue     

        # Spuštění konverzace s Gemini AI
        if conversation_mode:
            speak("Zpracovávám...")
            answer = ask_gemini(command)
            speak(answer)
        else:
            speak("Příkaz nebyl rozpoznán, pane.")

        # Záznam nerozpoznaného příkazu do logovacího souboru
        try:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(unknown_log_path, "a", encoding="utf-8") as log_f:
                log_f.write(f"[{timestamp}] {command}\n")
        except Exception as e:
            print(f"Error logging unknown command: {e}")