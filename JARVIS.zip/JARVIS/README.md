J.A.R.V.I.S. – AI Asistent

Je to v rychlosti z nudy vytvořený ai asistent. Mým cílem bylo vytvořit pomocníka, kterému můžu
úkoly zadávat jak slovně v češtině tak písemně. Použivam jak předprogramovany rozkazy na pc tak 
ai pro odpovídání na cokoli a generování kódů přímo do pc.

---

Hlavní funkce projektu
- Hlasové a textové příkazy: Interakce s asistentem v českém jazyce.
- Modulární systém pluginů: Možnost snadno přidávat nové funkce v samostatných 
souborech ve složce commands/.
- Lokální webové/mobilní rozhraní: Vestavěný HTTP server umožňuje ovládání aplikace
přes síť z mobilního zařízení či prohlížeče.
- Bezpečnostní pojistky: Ošetření chybějícího API klíče a automatická kontrola/instalace 
potřebných knihoven.

---

Požadavky a závislosti
Projekt vyžaduje nainstalovaný Python 3.8+. 
Všechny potřebné knihovny (jako `google-genai`, `SpeechRecognition`, `PyAutoGUI` apod.) se 
kontrolují a instalují automaticky při prvním spuštění skriptu.

---

📂 Struktura projektu
JARVIS/
│
├── core.py               # Hlavní spouštěcí soubor (backend, servery, logika)
├── config.json           # Konfigurační soubor (obsahuje nastavení a API klíč)
├── index.html            # Webové rozhraní pro mobilní zařízení / prohlížeč
├── commands/             # Složka pro vlastní rozšiřující moduly (pluginy)
└── JARVIS MEMORY/        # Datová složka pro poznámky, protokoly a záznamy

Pro přesné co umí se ho zeptejte: nápověda.
Pro fungování některých funkcí je třeba do config.json vložit api klíč gemini
Asistent se spouští buď přes main.py nebo dvojklikem na spustit.bat