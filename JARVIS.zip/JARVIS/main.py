import tkinter as tk
from hud import JarvisHUD

if __name__ == "__main__":
    # Vytvoření hlavního okna aplikace
    root = tk.Tk()
    
    # Inicializace grafického rozhraní (HUD) definovaného v souboru hud.py
    app = JarvisHUD(root)
    
    # Spuštění hlavní smyčky aplikace (okno zůstane otevřené a reaguje na akce)
    root.mainloop()