// Událost instalace Service Workera
// self.skipWaiting() zajišťuje, že se nový Service Worker aktivuje okamžitě bez čekání na restart prohlížeče
self.addEventListener('install', (event) => {
    self.skipWaiting();
});

// Událost aktivace Service Workera
// clients.claim() zajistí, že Service Worker okamžitě převezme kontrolu nad všemi otevřenými stránkami
self.addEventListener('activate', (event) => {
    event.waitUntil(clients.claim());
});

// Událost zachytávání síťových požadavků (fetch)
// Zkouší stáhnout obsah z internetu/serveru, a pokud selže (např. při výpadku spojení), vrátí data z mezipaměti (cache)
self.addEventListener('fetch', (event) => {
    event.respondWith(
        fetch(event.request).catch(() => {
            return caches.match(event.request);
        })
    );
});