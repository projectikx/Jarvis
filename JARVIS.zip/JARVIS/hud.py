import tkinter as tk
import math
import threading
import queue
import psutil
import datetime
import core

class JarvisHUD:
    """
    Hlavní třída pro grafické rozhraní (HUD) asistenta J.A.R.V.I.S.
    Využívá knihovnu Tkinter k vytvoření moderního sci-fi rozhraní inspirovaného filmy.
    """
    def __init__(self, root):
        self.root = root
        # Dynamicky načítá verzi z kořenového souboru core.VERSION
        self.root.title(f"J.A.R.V.I.S. // v.{core.VERSION}")
        
        # Nastavení okna na celou obrazovku (Fullscreen)
        self.is_fullscreen = True
        self.root.attributes("-fullscreen", True)

        # Klávesové zkratky: F11 a Escape přepínají celou obrazovku
        self.root.bind("<F11>", self.toggle_fullscreen)
        self.root.bind("<Escape>", self.toggle_fullscreen)

        # Základní tmavé pozadí laděné do sci-fi stylu
        self.root.config(bg="#02050a")

        # Hlavní kontejner pro všechny prvky rozhraní
        self.main_frame = tk.Frame(root, bg="#02050a")
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)

        # Horní stavová lišta (zobrazuje aktuální stav a hlášky asistenta)
        self.status_label = tk.Label(
            self.main_frame, 
            text="STATUS: STANDBY [AWAITING VOICE COMMAND]", 
            fg="#888888", 
            bg="#02050a", 
            font=("Consolas", 14, "bold")
        )
        self.status_label.pack(fill=tk.X, pady=(0, 10))

        # Střední mřížka rozdělující obrazovku na panely a animaci
        self.content_frame = tk.Frame(self.main_frame, bg="#02050a")
        self.content_frame.pack(fill=tk.BOTH, expand=True)

        # --- LEVÝ PANEL: SYSTEM MONITOR (Využití CPU a RAM v reálném čase) ---
        self.left_panel = tk.Frame(self.content_frame, bg="#050a14", bd=2, relief=tk.RIDGE)

        tk.Label(self.left_panel, text="[SYSTEM MONITOR]", fg="#00f3ff", bg="#050a14", font=("Consolas", 12, "bold")).pack(anchor="w", pady=5)
        self.cpu_label = tk.Label(self.left_panel, text="CPU: 0.0%", fg="#ffffff", bg="#050a14", font=("Consolas", 10))
        self.cpu_label.pack(anchor="w", pady=2)
        self.cpu_canvas = tk.Canvas(self.left_panel, width=200, height=15, bg="#02050a", highlightthickness=1, highlightbackground="#003344")
        self.cpu_canvas.pack(pady=5)
        self.cpu_bar = self.cpu_canvas.create_rectangle(0, 0, 0, 15, fill="#00f3ff", width=0)

        self.ram_label = tk.Label(self.left_panel, text="RAM: 0.0%", fg="#ffffff", bg="#050a14", font=("Consolas", 10))
        self.ram_label.pack(anchor="w", pady=(10, 2))
        self.ram_canvas = tk.Canvas(self.left_panel, width=200, height=15, bg="#02050a", highlightthickness=1, highlightbackground="#003344")
        self.ram_canvas.pack(pady=5)
        self.ram_bar = self.ram_canvas.create_rectangle(0, 0, 0, 15, fill="#00f3ff", width=0)

        self.net_label = tk.Label(self.left_panel, text="NET: CONNECTED", fg="#00f3ff", bg="#050a14", font=("Consolas", 10))
        self.net_label.pack(anchor="w", pady=(15, 2))

        # --- PRAVÝ PANEL: ČAS, DATUM A AKTIVNÍ PROTOKOLY ---
        self.right_panel = tk.Frame(self.content_frame, bg="#050a14", bd=2, relief=tk.RIDGE)

        tk.Label(self.right_panel, text="[ENVIRONMENT & TIME]", fg="#00f3ff", bg="#050a14", font=("Consolas", 12, "bold")).pack(anchor="w", pady=5)
        
        self.time_label = tk.Label(self.right_panel, text="Čas: --:--:--", fg="#ffffff", bg="#050a14", font=("Consolas", 11, "bold"))
        self.time_label.pack(anchor="w", pady=5)

        self.date_label = tk.Label(self.right_panel, text="Datum: --.--.----", fg="#ffffff", bg="#050a14", font=("Consolas", 10))
        self.date_label.pack(anchor="w", pady=5)

        tk.Label(self.right_panel, text="[AKTIVNÍ PROTOKOLY]", fg="#00f3ff", bg="#050a14", font=("Consolas", 12, "bold")).pack(anchor="w", pady=(20, 5))
        
        self.protocols_box = tk.Text(self.right_panel, width=25, height=15, bg="#02050a", fg="#ffffff", font=("Consolas", 9), bd=0, highlightthickness=0)
        self.protocols_box.pack(pady=5)
        self.protocols_box.config(state=tk.DISABLED)

        # --- STŘEDNÍ PANEL: 3D HUD ANIMACE (Kreslení rotující sféry na plátno) ---
        self.center_panel = tk.Frame(self.content_frame, bg="#02050a")
        self.center_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(self.center_panel, bg="#02050a", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.anim_angle = 0
        
        # Spuštění pravidelných smyček pro obnovování prvků
        self.animate_hud()
        self.update_system_stats()
        self.update_protocols_display()
        self.root.after(100, self.process_queue)

        # Vytvoření samostatného příkazového okna na PC
        self.init_command_window()

        # Spuštění hlavního jádra asistenta na pozadí v samostatném vlákně
        self.worker_thread = threading.Thread(target=core.jarvis_background_worker, daemon=True)
        self.worker_thread.start()

    def init_command_window(self):
        """Vytvoří vedlejší okno (Terminal) pro přímé zadávání příkazů na počítači."""
        self.cmd_win = tk.Toplevel(self.root)
        self.cmd_win.title(f"J.A.R.V.I.S. // Command Terminal v.{core.VERSION}")
        self.cmd_win.geometry("450x300+100+100")
        self.cmd_win.config(bg="#02050a")
        
        # Zavření okna pouze skryje, aby nedošlo k pádu aplikace
        self.cmd_win.protocol("WM_DELETE_WINDOW", lambda: self.cmd_win.withdraw())

        self.cmd_title_label = tk.Label(
            self.cmd_win, 
            text="[ DIRECT COMMAND TERMINAL ]", 
            fg="#00f3ff", 
            bg="#050a14", 
            font=("Consolas", 11, "bold")
        )
        self.cmd_title_label.pack(fill=tk.X, padx=10, pady=10, ipady=5)

        # Konzole pro výpis historie příkazů
        self.term_console = tk.Text(
            self.cmd_win, 
            bg="#010306", 
            fg="#00f3ff", 
            insertbackground="#00f3ff",
            font=("Consolas", 10), 
            bd=1, 
            relief=tk.SOLID,
            highlightthickness=1,
            highlightbackground="#003344"
        )
        self.term_console.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        self.term_console.insert(tk.END, "Terminal připraven. Napište příkaz níže, pane.\n")
        self.term_console.config(state=tk.DISABLED)

        bottom_frame = tk.Frame(self.cmd_win, bg="#02050a")
        bottom_frame.pack(fill=tk.X, padx=10, pady=10)

        # Vstupní pole pro napsání příkazu
        self.text_input = tk.Entry(
            bottom_frame, 
            bg="#050a14", 
            fg="#ffffff", 
            insertbackground="#ffffff",
            font=("Consolas", 11),
            relief=tk.SOLID,
            bd=1,
            highlightthickness=1,
            highlightbackground="#003344"
        )
        self.text_input.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        self.text_input.bind("<Return>", self.send_terminal_command)

        # Tlačítko pro odeslání příkazu
        self.send_btn = tk.Button(
            bottom_frame, 
            text="ODESLAT", 
            bg="#050a14", 
            fg="#00f3ff", 
            activebackground="#00f3ff",
            activeforeground="#02050a",
            font=("Consolas", 9, "bold"),
            command=self.send_terminal_command,
            relief=tk.SOLID,
            bd=1
        )
        self.send_btn.pack(side=tk.RIGHT)

    def send_terminal_command(self, event=None):
        """Odešle zadaný příkaz z terminálového okna do fronty jádra."""
        cmd = self.text_input.get().strip()
        if cmd:
            self.term_console.config(state=tk.NORMAL)
            self.term_console.insert(tk.END, f"> {cmd}\n")
            self.term_console.see(tk.END)
            self.term_console.config(state=tk.DISABLED)
            
            # Vložení příkazu do sdílené fronty
            core.command_queue.put(cmd.lower())
            core.log_to_gui(f"PC Terminal: {cmd}")
            
            self.text_input.delete(0, tk.END)

    def toggle_fullscreen(self, event=None):
        """Přepíná mezi celoobrazovkovým režimem a oknem."""
        self.is_fullscreen = not self.is_fullscreen
        self.root.attributes("-fullscreen", self.is_fullscreen)

    def update_protocols_display(self):
        """Pravidelně aktualizuje seznam aktivních protokolů v pravém panelu."""
        try:
            self.protocols_box.config(state=tk.NORMAL)
            self.protocols_box.delete("1.0", tk.END)
            
            content = (
                f"• J.A.R.V.I.S. v{core.VERSION}\n"
                "• PyTTSx3 Engine\n"
                "• Gemini AI Link\n"
                "• Watchdog Active\n"
                f"• Protokoly: {core.protocol}\n"
            )
            self.protocols_box.insert(tk.END, content)
            self.protocols_box.config(state=tk.DISABLED)
        except Exception as e:
            print(f"Chyba při aktualizaci protokolů v HUD: {e}")

        self.root.after(1000, self.update_protocols_display)

    def update_system_stats(self):
        """Zjišťuje aktuální vytížení CPU, RAM, čas a datum a vykresluje grafické bary."""
        try:
            cpu_usage = psutil.cpu_percent(interval=None)
            ram_info = psutil.virtual_memory()
            ram_usage = ram_info.percent

            self.cpu_label.config(text=f"CPU: {cpu_usage}%")
            self.cpu_canvas.coords(self.cpu_bar, 0, 0, int(2 * cpu_usage), 15)

            self.ram_label.config(text=f"RAM: {ram_usage}% ({ram_info.used // (1024**2)}MB)")
            self.ram_canvas.coords(self.ram_bar, 0, 0, int(2 * ram_usage), 15)

            now = datetime.datetime.now()
            self.time_label.config(text=f"Čas: {now.strftime('%H:%M:%S')}")
            self.date_label.config(text=f"Datum: {now.strftime('%d.%m.%Y')}")
        except Exception as e:
            print(f"Chyba při aktualizaci statistik: {e}")

        self.root.after(1000, self.update_system_stats)

    def animate_hud(self):
        """Vykresluje a animuje centrální 3D sféru (HUD) s ohledem na stav asistenta."""
        self.canvas.delete("all")
        
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w < 10: w = 600
        if h < 10: h = 600
        
        cx, cy = w / 2, h / 2
        
        scale = 1.15 if core.is_speaking else 1.0
        if core.is_speaking:
            scale += math.sin(self.anim_angle * 0.4) * 0.05

        # Dynamická změna barev podle aktuálního stavu (standby, talking, research, serious)
        state = core.assistant_state
        if state == "standby":
            outer_col, arc_col_1, arc_col_2, inner_col, core_col, text_col, label_fg = \
                "#333333", "#555555", "#444444", "#666666", "#333333", "#888888", "#888888"
        elif state == "talking":
            outer_col, arc_col_1, arc_col_2, inner_col, core_col, text_col, label_fg = \
                "#004411", "#00ff66", "#00cc44", "#00ff66", "#003311", "#00ff66", "#00ff66"
        elif state == "research":
            outer_col, arc_col_1, arc_col_2, inner_col, core_col, text_col, label_fg = \
                "#665500", "#ffcc00", "#ffaa00", "#ffcc00", "#443300", "#ffcc00", "#ffcc00"
        elif state == "serious":
            outer_col, arc_col_1, arc_col_2, inner_col, core_col, text_col, label_fg = \
                "#660000", "#ff1100", "#cc0000", "#ff3333", "#440000", "#ff5555", "#ff1100"
        else:
            outer_col, arc_col_1, arc_col_2, inner_col, core_col, text_col, label_fg = \
                "#003344", "#00f3ff", "#00aaff", "#00f3ff", "#004466", "#ffffff", "#00f3ff"

        # Zobrazení nebo skrytí bočních panelů podle stavu
        if state in ["active", "talking"]:
            if not self.left_panel.winfo_ismapped():
                self.left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10), ipadx=10, ipady=10, before=self.center_panel)
            if not self.right_panel.winfo_ismapped():
                self.right_panel.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0), ipadx=10, ipady=10)
        else:
            if self.left_panel.winfo_ismapped():
                self.left_panel.pack_forget()
            if self.right_panel.winfo_ismapped():
                self.right_panel.pack_forget()

        self.status_label.config(fg=label_fg)
        if state in ["active", "talking"]:
            self.left_panel.config(highlightbackground=label_fg)
            self.right_panel.config(highlightbackground=label_fg)
            self.cpu_canvas.config(highlightbackground=outer_col)
            self.ram_canvas.config(highlightbackground=outer_col)
            self.canvas.itemconfig(self.cpu_bar, fill=label_fg)
            self.canvas.itemconfig(self.ram_bar, fill=label_fg)

        try:
            if hasattr(self, 'cmd_win') and self.cmd_win.winfo_exists():
                self.cmd_title_label.config(fg=label_fg)
                self.term_console.config(fg=label_fg, insertbackground=label_fg, highlightbackground=outer_col)
                self.text_input.config(highlightbackground=outer_col)
                self.send_btn.config(fg=label_fg, activebackground=label_fg)
        except Exception as e:
            print(f"Chyba při barvení cmd okna: {e}")

        angle_x = self.anim_angle * 0.02
        angle_y = self.anim_angle * 0.03
        angle_z = self.anim_angle * 0.01

        def rotate_and_project(x, y, z, radius_scale):
            """Matematická 3D projekce bodů na 2D plátno."""
            rad = angle_x
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            y, z = y * cos_a - z * sin_a, y * sin_a + z * cos_a

            rad = angle_y
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            x, z = x * cos_a + z * sin_a, -x * sin_a + z * cos_a

            rad = angle_z
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            x, y = x * cos_a - y * sin_a, x * sin_a + y * cos_a

            distance = 400
            factor = distance / (distance + z)
            px = cx + x * factor * radius_scale
            py = cy + y * factor * radius_scale
            return px, py, z

        base_radius = int(180 * scale)

        # Vykreslení zeměpisných šířek (latitudes) sféry
        num_latitudes = 5
        for i in range(-num_latitudes, num_latitudes + 1):
            lat_fraction = i / num_latitudes
            r_ring = base_radius * math.sqrt(max(0.0, 1.0 - lat_fraction**2))
            z_offset = base_radius * lat_fraction
            
            points = []
            steps = 30
            for step in range(steps + 1):
                theta = (step / steps) * 2 * math.pi
                px, py, _ = rotate_and_project(math.cos(theta) * r_ring, z_offset, math.sin(theta) * r_ring, 1.0)
                points.append((px, py))
            
            col = arc_col_1 if i % 2 == 0 else arc_col_2
            for p in range(len(points) - 1):
                self.canvas.create_line(points[p][0], points[p][1], points[p+1][0], points[p+1][1], fill="#001122", width=5)
                self.canvas.create_line(points[p][0], points[p][1], points[p+1][0], points[p+1][1], fill=col, width=2)

        # Vykreslení poledníků (meridians)
        num_meridians = 4
        for m in range(num_meridians):
            m_angle = (m / num_meridians) * math.pi
            points = []
            steps = 30
            for step in range(steps + 1):
                phi = (step / steps) * 2 * math.pi
                x = base_radius * math.cos(phi) * math.cos(m_angle)
                y = base_radius * math.sin(phi)
                z = base_radius * math.cos(phi) * math.sin(m_angle)
                px, py, _ = rotate_and_project(x, y, z, 1.0)
                points.append((px, py))

            for p in range(len(points) - 1):
                self.canvas.create_line(points[p][0], points[p][1], points[p+1][0], points[p+1][1], fill=outer_col, width=1)

        # Vykreslení rotující oběžné dráhy (orbit)
        orbit_radius = int(230 * scale)
        orbit_points = []
        steps = 40
        for step in range(steps + 1):
            theta = (step / steps) * 2 * math.pi
            ox = math.cos(theta) * orbit_radius
            oy = math.sin(theta) * orbit_radius * 0.4
            oz = math.sin(theta) * orbit_radius * 0.9
            px, py, _ = rotate_and_project(ox, oy, oz, 1.0)
            orbit_points.append((px, py))

        for p in range(len(orbit_points) - 1):
            self.canvas.create_line(orbit_points[p][0], orbit_points[p][1], orbit_points[p+1][0], orbit_points[p+1][1], fill=arc_col_1, width=2, dash=(4, 2))

        # Vykreslení středového jádra s nápisem J.A.R.V.I.S.
        r_core = int(75 * scale)
        self.canvas.create_oval(cx - r_core, cy - r_core, cx + r_core, cy + r_core, outline=inner_col, width=3)
        self.canvas.create_oval(cx - (r_core - 8), cy - (r_core - 8), cx + (r_core - 8), cy + (r_core - 8), outline=core_col, width=1)

        font_size = int(16 * scale)
        self.canvas.create_text(cx, cy, text="J.A.R.V.I.S.", fill=text_col, font=("Consolas", font_size, "bold"))

        self.anim_angle += 1
        self.root.after(30, self.animate_hud)

    def process_queue(self):
        """Zpracovává zprávy z fronty grafického rozhraní a aktualizuje stavový řádek."""
        try:
            while True:
                msg = core.gui_queue.get_nowait()
                self.status_label.config(text=msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_queue)