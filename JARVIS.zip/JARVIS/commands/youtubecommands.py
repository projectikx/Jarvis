import webbrowser
import pyautogui

def handle_command(context):
    command = context["command"]
    speak = context["speak"]

    if "zapni video" in command:
        query = command.replace("zapni video", "").strip()
        if query:
            speak(f"Vyhledávám video {query}, pane.")
            url = f"[https://www.youtube.com/results?search_query=](https://www.youtube.com/results?search_query=){query.replace(' ', '+')}"
            webbrowser.open(url)
        else:
            speak("Nezadal jste název videa, pane.")
        return True
    
    elif "zapni kanál" in command:
        query = command.replace("zapni kanál", "").strip()
        if query:
            speak(f"Vyhledávám kanál {query}, pane.")
            url = f"[https://www.youtube.com/results?search_query=](https://www.youtube.com/results?search_query=){query.replace(' ', '+')}&sp=EgIQAg%253D%253D"
            webbrowser.open(url)
        else:
            speak("Nezadal jste název kanálu, pane.")
        return True

    elif "sjeď níž" in command or "dolů" in command:
        speak("Posouvám stránku dolů, pane.")
        pyautogui.scroll(-500)
        return True

    elif "vyjeď výš" in command or "nahoru" in command:
        speak("Posouvám stránku nahoru, pane.")
        pyautogui.scroll(500)
        return True
    return False