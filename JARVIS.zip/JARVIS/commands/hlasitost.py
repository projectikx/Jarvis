import os
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    
    # Podmínka pro příkaz
    if any(w in command for w in ["volume down", "quieter", "lower volume", "ztlum", "tišeji"]):
        odpoved = random.choice(["Snižuji hlasitost, pane.", "Hlasitost snížena, pane.", "Ztlumeno, pane."])
        speak(odpoved)
        ps_vol = "$w = New-Object -ComObject WScript.Shell; for($i=0; $i -lt 7; $i++) { $w.SendKeys([char]174); Start-Sleep -Milliseconds 50 }"
        os.system(f'powershell -Command "{ps_vol}"')
        return True
    elif any(w in command for w in ["volume up", "louder", "raise volume", "zesil", "nahlas"]):
        odpoved = random.choice(["Zvyšuji hlasitost, pane.(nejedu)", "Hlasitost zvýšena, pane.(nejedu)", "Zvýšeno, pane.(nejedu)"])
        speak(odpoved)
        ps_vol = "$w = New-Object -ComObject WScript.Shell; for($i=0; $i -lt 7; $i++) { $w.SendKeys([char]175); Start-Sleep -Milliseconds 50 }"
        os.system(f'powershell -Command "{ps_vol}"')
        return True # Řekneme core.py: "Hotovo, dál to neřeš!"
        
    return False # Pokud to nebylo YouTube, jdeme dál