def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    nastav_hodnotu = context["nastav_hodnotu"]
    sci_fi_beep = context["sci_fi_beep"]
    smaz_hodnotu = context["smaz_hodnotu"]
    
    # Můžeš sem předat i globální funkce/proměnné, pokud je potřebuješ upravovat
    # (v core.py si ale můžeš nastavit, že modul zavolá zpětnou vazbu)
    
    if "protokol mluvení" in command or "zapni rozhovor" in command:
        conversation_mode = True
        assistant_state = "talking"
        nastav_hodnotu("rozhovor")
        sci_fi_beep(1600, 2400, 80)
        speak("Protokol mluvení aktivován. Nyní můžeme volně konverzovat, pane.")
        return True

    if "vypni rozhovor" in command or "konec rozhovoru" in command:
        conversation_mode = False
        smaz_hodnotu("rozhovor")
        assistant_state = "active"
        sci_fi_beep(1800, 1000, 80)
        speak("Protokol mluvení deaktivován, pane.")
        return True
        
    return False