import core
import os
import datetime

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    nastav_hodnotu = context["nastav_hodnotu"]
    smaz_hodnotu = context["smaz_hodnotu"]
    sci_fi_beep = context["sci_fi_beep"]
    memory_folder = context["memory_folder"]
    collected_research_data = []

    if any(w in command for w in ["search mode on", "start searching", "zapni hledací mód", "zapni hledani", "zapni hledání", "protocol hledání", "protokol hledání"]):
        # Opraveno na core.research_mode_active
        if not core.research_mode_active:
            core.research_mode_active = True
            nastav_hodnotu("hledací mód")
            sci_fi_beep(1300, 1900, 90)
            speak("Vyhledávací mód aktivován, pane.")
        else:
            speak("Vyhledávací mód je již aktivní, pane.")
        return True
    
    if any(w in command for w in ["search mode off", "stop searching", "vypni hledací mód", "vypni hledani", "vypni hledání"]):
        # Opraveno na core.research_mode_active
        if core.research_mode_active:
            core.research_mode_active = False
            core.assistant_state = "active"
            smaz_hodnotu("hledací mód")
            sci_fi_beep(1900, 1300, 90)
            speak("Ukončuji vyhledávací mód, pane. Sestavuji zprávu do souboru.")
            report_path = os.path.join(memory_folder, "JARVIS_Research_Report.txt")
            try:
                with open(report_path, "w", encoding="utf-8") as rep_file:
                    rep_file.write("==================================================\n")
                    rep_file.write("   J.A.R.V.I.S. INTELLIGENCE RESEARCH REPORT    \n")
                    rep_file.write(f"   Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}   \n")
                    rep_file.write("==================================================\n\n")
                    if collected_research_data:
                        for idx, entry in enumerate(collected_research_data, 1):
                            rep_file.write(f"[PRIORITY {idx}] CATEGORY: {entry['category']}\n")
                            rep_file.write(f"Timestamp: {entry['timestamp']}\n")
                            rep_file.write("-" * 50 + "\n")
                            rep_file.write(f"{entry['content']}\n\n")
                    else:
                        rep_file.write("Během této relace nebyla shromážděna žádná zpravodajská data, pane.\n")
                speak("Zpráva byla úspěšně zkompilována a uložena do vašeho paměťového adresáře, pane.")
                os.startfile(report_path)
            except Exception as e:
                speak(f"Nepodařilo se zapsat zprávu z výzkumu, pane. Chyba: {e}")
        else:
            speak("Vyhledávací mód nebyl aktivní, pane.")
        return True
    return False