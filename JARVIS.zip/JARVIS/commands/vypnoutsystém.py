import os
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]

    if any(w in command for w in ["shutdown computer", "turn off system", "vypni počítač", "vypnout systém"]):
        odpoved = random.choice(["Varování: Deaktivuji hlavní reaktor a vypínám systém, pane.", "Upozornění: Hlavní reaktor bude deaktivován a systém se vypne, pane.", "Pozor: Vypínám systém a deaktivuji hlavní reaktor, pane."])
        speak(odpoved)
        os.system("shutdown /s /t 5")
        return True

    return False