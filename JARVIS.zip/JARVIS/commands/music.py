import webbrowser
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    
    # Podmínka pro příkaz
    if "music" in command:
        odpoved = random.choice(["Spouštím hudbu, pane.", "Přehrávám hudbu, pane.", "Nyní přehrávám hudbu, pane."])
        speak(odpoved)
        webbrowser.open("[https://www.youtube.com](https://www.youtube.com)")
        return True # Řekneme core.py: "Hotovo, dál to neřeš!"
        
    return False # Pokud to nebylo YouTube, jdeme dál