def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    VERSION = context["VERSION"]  # Získání verze z kontextu, pokud existuje
    
    # Podmínka pro příkaz
    if any(word in command for word in ["help", "what can you do", "capabilities", "co umíš", "nápověda"]):
        base_help = (
            f"Pane, jsem ve verzi {VERSION}. Mezi mé pevné příkazy patří: Zjištění času, nahlášení datumu, otevření googlu, "
            "ovládání hlasitosti, protocoly v indexu, řeknutí informací o mě, zjištění IP adresy, programování přímo v pc za pomocí ai a terminálu, zapnutí krizového protocolu"
            "zapnutí hudby, zobrazení nápovědy, zapsání poznámky, zjištění počasí,zapsání příkazu do indexu,"
            "mluvení uživatele s gemini bez nutnosti na začátku řeknutí řekni, moje restartování, poslání zprávi gemini začínající řekni,"
            "aktualizace příkazů bez nutnosti aktualizace celého programu, moje vypnutí, vypnutí počítače, otevření youtube, ovládání youtube a propojení pc s mobilem že vše mužu dělat z mobilu."
        )
        speak(base_help)
        return True # Řekneme core.py: "Hotovo, dál to neřeš!"
        
    return False # Pokud to nebylo YouTube, jdeme dál