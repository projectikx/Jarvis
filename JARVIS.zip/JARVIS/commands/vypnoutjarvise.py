import os
import time
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]

    if any(w in command for w in ["vypni se", "shut down jarvis", "vypni jarvis", "kill"]):
        odpoved = random.choice(["Vypínám J.A.R.V.I.S.e, pane.", "J.A.R.V.I.S. se vypíná, pane.", "Deaktivace J.A.R.V.I.S.e probíhá, pane.", "Zvládnete to bez J.A.R.V.I.S.e, pane?"])
        speak(odpoved)
        time.sleep(2.5)
        os._exit(0)
        return True

    return False