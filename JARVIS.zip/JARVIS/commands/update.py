import core
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    
    if any(w in command for w in ["update", "aktualizovat", "načíst příkazy", "reload"]):
        řeč = random.choice(["Aktualizuji moduly příkazů, pane.", "Načítám nové příkazy, pane.", "Probíhá aktualizace příkazů, pane."])
        speak(řeč)
        try:
            # Znovu spustí načítání pluginů za běhu
            core.load_command_plugins()
            odpoved = random.choice(["Aktualizace dokončena, pane.", "Všechny příkazy byly úspěšně zaktualizovány, pane.", "Načítání příkazů bylo úspěšné, pane."])
            speak(odpoved)
        except Exception as e:
            print(f"Chyba při aktualizaci pluginů: {e}")
            error = random.choice(["Při aktualizaci modulů došlo k chybě, pane.", "Aktualizace příkazů selhala, pane.", "Nepodařilo se načíst nové příkazy, pane."])
            speak(error)
        return True
        
    return False