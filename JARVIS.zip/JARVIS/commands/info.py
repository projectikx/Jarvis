# Ukázkový modul pro příkazy informací o systému
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    VERSION = context["VERSION"]
    
    # Seznam klíčových slov, na které tento soubor zareaguje
    keywords = ["jarvis info", "informace", "kdo jsi"]
    odpoved = random.choice([
        "Jsem J.A.R.V.I.S., váš osobní hlasový asistent.",
        "Jsem vaším osobním hlasovým asistentem, J.A.R.V.I.S.",
        "Jsem J.A.R.V.I.S., Váš pomocník vyvinutý Janem Pátečkem.",
        "Jsem J.A.R.V.I.S. verze {VERSION}, váš osobní hlasový asistent, pane."
    ])

    if any(word in command for word in keywords):
        speak(odpoved.format(VERSION=VERSION))
        return True # Vracíme True -> core.py bude vědět, že příkaz byl vyřízen
        
    return False # Pokud to nepatří sem, vrátíme False a jedou dál ostatní příkazy