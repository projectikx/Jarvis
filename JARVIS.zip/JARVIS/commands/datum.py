import datetime
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    
    # Podmínka pro příkaz
    if any(word in command for word in ["den", "datum"]):
        now = datetime.datetime.now()
        odpověď = random.choice([f"Dnes je {now.strftime('%d.%m.%Y')}, pane.", f"Aktuální datum je {now.strftime('%d.%m.%Y')}, pane.", f"Právě je {now.strftime('%d.%m.%Y')}, pane."])
        speak(odpověď)
        return True # Řekneme core.py: "Hotovo, dál to neřeš!"
        
    return False # Pokud to nebylo YouTube, jdeme dál