import os
import time
import sys
import subprocess

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    http_server_instance = context.get("http_server_instance", None)  # Získání instance serveru z kontextu, pokud existuje
    
    if any(w in command for w in ["reset jarvis", "restart jarvis", "restartuj jarvis", "restart"]):
        speak("Provádím restart systému a obnovení mobilního připojení, pane.")
        time.sleep(1.5)
        # Odsazení opraveno zde:
        try:
            # Pokud potřebuješ http_server_instance, můžeš si ji vyžádat z contextu, 
        # nebo pokud v tomhle souboru globálně neexistuje, ošetříme to:
            if 'http_server_instance' in globals() and http_server_instance:
                http_server_instance.shutdown()
                http_server_instance.server_close()
        except Exception as e:
            print(f"Chyba při zavírání serveru: {e}")            
        try:
            subprocess.Popen([sys.executable, sys.argv[0]])
        except Exception as e:
            print(f"Chyba při restartu: {e}")
            
        os._exit(0)
        return True
        
    return False