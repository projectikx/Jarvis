import datetime
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    
    # Podmínka pro příkaz
    if any(word in command for word in ["time", "hodin", "čas"]):
        now = datetime.datetime.now()
        odpověď = random.choice([f"Je právě {now.hour} hodin a {now.minute} minut, pane.", f"Aktuální čas je {now.hour}:{now.minute}, pane.", f"Právě je {now.hour} hodin a {now.minute} minut, pane."])
        speak(odpověď)
        return True
        
    return False