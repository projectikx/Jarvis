import webbrowser
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    
    # Podmínka pro příkaz
    if "youtube" in command:
        odpovedi = [
            "Otevírám YouTube, pane.",
            "Jistě, pane. Spouštím YouTube.",
            "Samozřejmě, pane. Otevírám YouTube.",
            "Pane, právě otevírám YouTube pro vás.",
            "YouTube se spouští, pane."
        ]
        speak(random.choice(odpovedi))
        webbrowser.open("https://www.youtube.com")
        return True # Řekneme core.py: "Hotovo, dál to neřeš!"
        
    return False # Pokud to nebylo YouTube, jdeme dál