import socket
import random

def get_local_ip():
    """Získá lokální IP adresu počítače v síti."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except:
            return "127.0.0.1"

def handle_command(context):
    command = context["command"]
    speak = context["speak"]

    if any(w in command for w in ["ip adresa", "moje ip", "ip address"]):
        current_ip = get_local_ip()
        odpoved = random.choice([f"Vaše lokální IP adresa je {current_ip}, pane.", f"Aktuální IP adresa vašeho počítače je {current_ip}, pane.", f"Právě zjištěná lokální IP adresa je {current_ip}, pane."])
        speak(odpoved)
        return True

    return False