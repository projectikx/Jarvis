import os
import time
import pyautogui
import core  # <-- Důležité: Přidat import core
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    nastav_hodnotu = context["nastav_hodnotu"]
    smaz_hodnotu = context["smaz_hodnotu"]
    sci_fi_beep = context["sci_fi_beep"]
    smart_screenshot = context["smart_screenshot"]

    # Opraveno na core.assistant_state
    if "krize" in command and core.assistant_state != "serious":
        core.assistant_state = "serious"
        nastav_hodnotu("krize")
        sci_fi_beep(700, 400, 120)
        odpoved = random.choice(["Protokol krize aktivován. Zachycuji obrazovku pro bezpečnostní záznam a zamykám systém. Méně paniky, více disciplíny, pane.", "Krize aktivována. Žádná panika, pane."])
        speak(odpoved)
        smart_screenshot(reason="Krizový protokol aktivován uživatelem")
        try:
            pyautogui.hotkey('win', 'd')
            time.sleep(0.3)
            os.system("rundll32.exe user32.dll,LockWorkStation")
        except Exception as e:
            print(f"Crisis mode execution error: {e}")
        return True

    if any(w in command for w in ["konec krize", "normální režim", "zrušit krizi"]):
        # Opraveno na core.assistant_state
        if core.assistant_state == "serious":
            core.assistant_state = "active"
            smaz_hodnotu("krize")
            sci_fi_beep(1500, 2200, 80)
            odpoved = random.choice(["Krizový protokol deaktivován. Vracím se do standardního režimu, pane.", "Krizový protokol ukončen. Vše je nyní v normálním režimu, pane.", "Panika skončila již je vše jak má být, pane."])
            speak(odpoved)
        else:
            speak("Nejste v krizovém režimu, pane.")
        return True
        
    return False