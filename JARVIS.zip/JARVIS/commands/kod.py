import os
import re

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    memory_folder = context["memory_folder"]
    ask_gemini = context["ask_gemini"]

    if command.startswith("kod ") or command.startswith("programuj "):
        try:
            matches = re.findall(r"['\"](.+?)['\"]", command)
            if not matches:
                speak("Chybí názvy souborů v uvozovkách, pane.")
                return True
            
            target_filenames = [m.strip() for m in matches]
            
            last_match_idx = command.rfind(matches[-1])
            user_prompt = command[last_match_idx + len(matches[-1]) + 1:].replace("'", "").replace('"', "").replace("uprav", "").strip()

            if not user_prompt:
                user_prompt = "Vytvoř nebo vylepši tyto skripty."

            speak(f"Zpracovávám požadavek pro soubory: {', '.join(target_filenames)}, pane.")
                
            files_data = {}
            for filename in target_filenames:
                fname = filename
                if "." not in fname:
                    fname += ".py"
                f_path = os.path.join(memory_folder, fname)
                    
                existing_code = ""
                if os.path.exists(f_path):
                    with open(f_path, "r", encoding="utf-8") as f:
                        existing_code = f.read()
                files_data[fname] = existing_code

            prompt_text = (
                "You are an expert Python developer assisting J.A.R.V.I.S. "
                "The user wants to modify or create multiple specific Python scripts.\n\n"
                f"User request / instructions: {user_prompt}\n\n"
                "Here are the target files and their current contents:\n"
            )
                
            for fname, code in files_data.items():
                prompt_text += f"--- FILE: {fname} ---\n```python\n{code}\n```\n\n"

            prompt_text += (
                "CRITICAL INSTRUCTIONS:\n"
                "1. Modify ONLY the requested files according to the instructions.\n"
                "2. For each file you modify, return its code enclosed in a mar wn block specifying the filename, like this:\n"
                "```python:filename.py\n... code here ...\n```\n"
                "3. Do not include any conversational filler outside the code blocks."
            )

            ai_response = ask_gemini(prompt_text)

            file_blocks = re.findall(r"```python[:\s]*([^\n]+)?\n(.*?)```", ai_response, re.DOTALL)
                
            if file_blocks:
                for block_name, block_code in file_blocks:
                    block_name = block_name.strip() if block_name else ""
                    matched_file = None
                    for tf in files_data.keys():
                        if tf in block_name:
                            matched_file = tf
                            break
                    if not matched_file and len(file_blocks) == len(target_filenames):
                        matched_file = list(files_data.keys())[file_blocks.index((block_name, block_code))]

                    if matched_file:
                        clean_code = block_code.strip()
                        file_path = os.path.join(memory_folder, matched_file)
                        with open(file_path, "w", encoding="utf-8") as f:
                            f.write(clean_code)
                speak(f"Všechny vybrané soubory byly úspěšně upraveny a uloženy, pane.")
            else:
                clean_code = ai_response
                if "```python" in ai_response:
                    parts = ai_response.split("```python")
                    if len(parts) > 1:
                            clean_code = parts[1].split("```")[0].strip()
                
                target_file = list(files_data.keys())[0]
                file_path = os.path.join(memory_folder, target_file)
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(clean_code)
                speak(f"Kód byl uložen do souboru {target_file}, pane.")
                
        except Exception as e:
            print(f"Chyba při vícenásobném programovacím protokolu: {e}")
            speak("Při zpracování kódů došlo k chybě, pane.")
        return True
    return False