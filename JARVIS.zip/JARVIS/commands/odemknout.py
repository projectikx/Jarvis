import random
import os
from time import time
import pyautogui

def handle_command(context):
    commands = context["command"]
    speak = context["speak"]
    
    if any(w in commands for w in ["unlock", "odemknout", "odblokovat"]):
        odpoved = random.choice(["Odemknu zařízení, pane.", "Probíhá odemykání, pane.", "Odemknutí probíhá, pane.", "Zařízení se odemyká, pane."])
        speak(odpoved)
        pyautogui.press('enter')
        time.sleep(1)
        pyautogui.write('951753', interval=0.1)
        time.sleep(0.5)
        pyautogui.press('enter')
        return True
    return False