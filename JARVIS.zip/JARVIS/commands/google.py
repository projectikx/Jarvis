import webbrowser
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    
    # Podmínka pro příkaz
    if "google" in command:
        odpoved = random.choice(["Otevírám Google, pane.", "Spouštím Google, pane.", "Nyní otevírám Google, pane."])
        speak(odpoved)
        webbrowser.open("[https://www.google.com](https://www.google.com)")
        return True # Řekneme core.py: "Hotovo, dál to neřeš!"
        
    return False # Pokud to nebylo YouTube, jdeme dál