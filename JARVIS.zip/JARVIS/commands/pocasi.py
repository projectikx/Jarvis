import os
import random
import requests

def handle_command(context):
    command = context["command"]
    speak = context["speak"]

    # Reaguje na české i anglické dotazy na počasí
    if any(w in command for w in ["weather", "pocasi", "počasí", "jaké je počasí", "jaké je pocasi"]):
        odpoved_start = random.choice([
            "Zjišťuji aktuální počasí, pane.", 
            "Hledám předpověď počasí, pane.", 
            "Zjišťuji stav počasí, pane."
        ])
        speak(odpoved_start)
        
        try:
            # Stáhne aktuální počasí pro Letovice (můžeš si přepsat město v URL, např. Brno)
            # ?format=3 vrátí stručný text ve formátu: "Letovice: ⛅ +15°C"
            url = "https://wttr.in/Letovice?format=3"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                weather_text = response.text.strip()
                # Převedeme na přirozenější větu pro hlasovou Syntézu
                vysledek = f"Venku je aktuálně: {weather_text}"
            else:
                vysledek = "Omlouvám se, pane, ale nepodařilo se mi načíst aktuální data o počasí."
                
        except Exception as e:
            vysledek = "Omlouvám se, pane, nastala chyba při připojení k internetu."

        # Asistent to řekne nahlas
        speak(vysledek)
        return True

    return False