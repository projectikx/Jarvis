import os
import subprocess
import pyautogui

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    index_path = context["index_path"]
    memory_folder = context["memory_folder"]

    custom_action_executed = False
    if os.path.exists(index_path):
        try:
            with open(index_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        return True
                    parts = line.split("|")
                    if len(parts) == 3:
                        trigger = parts[0].strip().lower()
                        action_type = parts[1].strip().lower()
                        value = parts[2].strip()
                        if trigger in command:
                            custom_action_executed = True
                            if action_type == "open":
                                file_path = os.path.join(memory_folder, value)
                                if os.path.exists(file_path):
                                    speak(f"Spouštím protokol pro {trigger}, pane.")
                                    os.startfile(file_path)
                                else:
                                    speak(f"Protokolový soubor {value} nebyl nalezen, pane.")
                            elif action_type == "folder":
                                target_folder = value if ":" in value else os.path.join(memory_folder, value)
                                if os.path.exists(target_folder):
                                    speak(f"Otevírám složku pro {trigger}, pane.")
                                    os.startfile(target_folder)
                                else:
                                    speak(f"Složka {value} nebyla nalezena, pane.")
                            elif action_type == "app":
                                speak(f"Spouštím aplikaci pro {trigger}, pane.")
                                try:
                                    os.startfile(value)
                                except Exception:
                                    os.system(f'start "" "{value}"')
                            elif action_type == "cmd":
                                speak(f"Vykonávám systémový příkaz pro {trigger}, pane.")
                                try:
                                    subprocess.Popen(value, shell=True)
                                except Exception as e:
                                    print(f"CMD execution error: {e}")
                            elif action_type == "speak":
                                speak(value)
                            elif action_type == "delete":
                                file_path = os.path.join(memory_folder, value)
                                if os.path.exists(file_path):
                                    os.remove(file_path)
                                    speak(f"Cíl {value} byl vymazán, pane.")
                                else:
                                    speak(f"Cíl {value} k smazání nebyl nalezen, pane.")
                            elif action_type in ["keys", "hotkey", "press"]:
                                speak(f"Spouštím zkratku pro {trigger}, pane.")
                                try:
                                    keys_list = [k.strip() for k in value.split('+')]
                                    pyautogui.hotkey(*keys_list)
                                except Exception as e:
                                    print(f"Hotkey error: {e}")
        except Exception as e:
            print(f"Index parsing error: {e}")

    if custom_action_executed:
        return True
    return False