import core
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]

    command_clean = command.replace("řekni", "rekni")
    if command_clean.startswith("rekni ") or "rekni " in command_clean:
        if command_clean.startswith("rekni "):
            query_text = command_clean[6:].strip()
        else:
            query_text = command_clean.split("rekni ", 1)[1].strip()
    
        if query_text:
            odpoved = random.choice([
                "Zpracovávám váš požadavek, pane.",
                "Hledám odpověď na váš dotaz, pane.",
                "Chvíli strpení, pane, zpracovávám váš příkaz.",
                "Zpracovávám..."
            ])
            speak(odpoved)
            # Voláme ask_gemini přímo z core.py, kde už má přístup k assistant_state i ke klientovi
            answer = core.ask_gemini(query_text)
            speak(answer)
        return True

    return False