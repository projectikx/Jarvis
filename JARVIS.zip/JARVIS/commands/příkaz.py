def handle_command(context):
    speak = context["speak"]
    command = context["command"]
    prikaz_path = context["prikaz_path"]

    if command.startswith("příkaz ") or command.startswith("prikaz "):
        raw_cmd_text = command.replace("příkaz", "", 1).replace("prikaz", "", 1).strip()
        if raw_cmd_text:
            try:
                with open(prikaz_path, "a", encoding="utf-8") as f:
                    f.write(f"{raw_cmd_text}\n")
                speak(f"Nový příkaz byl úspěšně zapsán do indexu, pane: {raw_cmd_text}")
                return True
            except Exception as e:
                speak(f"Chyba při zápisu příkazu do indexu, pane: {e}")
                return True
        else:
            speak("Zadal jste prázdný příkaz, pane.")
            return True
    return False