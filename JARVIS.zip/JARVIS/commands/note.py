import datetime
import speech_recognition as sr
import random

def handle_command(context):
    command = context["command"]
    speak = context["speak"]
    notes_path = context["notes_path"]
    log_to_gui = context["log_to_gui"]
    DEFAULT_LANGUAGE = context["default_language"]

    if any(w in command for w in ["note", "add note", "zapiš poznámku", "poznámka", "zapsat poznámku", "poznamenej si"]):
        odpoved = random.choice(["Poslouchám vaši poznámku, pane.", "Zaznamenávám poznámku, pane.", "Můžete mi sdělit obsah poznámky, pane?", "Jsem připraven zaznamenat vaši poznámku, pane."])
        speak(odpoved)
        r_note = sr.Recognizer()
        note_content = ""
        try:
            with sr.Microphone() as source:
                r_note.adjust_for_ambient_noise(source, duration=0.5)
                audio = r_note.listen(source, timeout=30, phrase_time_limit=None)
                try:
                    note_content = r_note.recognize_google(audio, language=DEFAULT_LANGUAGE)
                except:
                    try:
                        note_content = r_note.recognize_google(audio, language="en-US")
                    except:
                        pass
        except Exception as e:
            log_to_gui(f"Note mic error: {e}")
    
        if note_content:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            try:
                with open(notes_path, "a", encoding="utf-8") as n_file:
                    n_file.write(f"[{timestamp}] {note_content}\n")
                odpoved = random.choice(["Poznámka byla úspěšně zaznamenána, pane.", "Vaše poznámka byla uložena, pane.", "Zapsal jsem vaši poznámku do paměti, pane."])
                speak(odpoved)
            except Exception as e:
                odpoved = random.choice(["Nepodařilo se zapsat poznámku, pane. Chyba: {e}", "Chyba při ukládání poznámky, pane."])
                speak(odpoved)
        else:
            odpoved = random.choice(["Nezaznamenal jsem žádný hlas pro poznámku, pane.", "Nebyla zachycena žádná poznámka, pane.", "Nepodařilo se zachytit obsah poznámky, pane."])
            speak(odpoved)
        return True
    return False